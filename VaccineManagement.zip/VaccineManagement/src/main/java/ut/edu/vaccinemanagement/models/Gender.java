package ut.edu.vaccinemanagement.models;

public enum Gender {
    Male,Female,Other
}
