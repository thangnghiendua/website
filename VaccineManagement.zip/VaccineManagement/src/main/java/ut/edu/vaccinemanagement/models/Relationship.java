package ut.edu.vaccinemanagement.models;

public enum Relationship {
    Mother, Father,Guardian
}
