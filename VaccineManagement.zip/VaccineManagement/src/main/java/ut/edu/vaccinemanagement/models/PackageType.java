package ut.edu.vaccinemanagement.models;

public enum PackageType {
    Single_Package, Combo,Personalization
}
