package ut.edu.vaccinemanagement.models;

public enum AppointmentStatus {
    Complete,Pending,Canceled,Confirmed
}
