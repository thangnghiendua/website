package ut.edu.vaccinemanagement.models;

public enum UserRole {
    User,Admin,Doctor
}
