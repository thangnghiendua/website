package ut.edu.vaccinemanagement.models;

public enum NotificationStatus {
    Read, have_not_read_yet
}
