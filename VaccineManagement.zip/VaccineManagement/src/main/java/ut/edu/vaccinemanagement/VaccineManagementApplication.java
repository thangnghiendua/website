package ut.edu.vaccinemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaccineManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(VaccineManagementApplication.class, args);
    }

}
