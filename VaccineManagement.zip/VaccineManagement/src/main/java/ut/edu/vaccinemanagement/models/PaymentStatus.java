package ut.edu.vaccinemanagement.models;

public enum PaymentStatus {
    SUCCESS,FAILED,Are_Trading
}
