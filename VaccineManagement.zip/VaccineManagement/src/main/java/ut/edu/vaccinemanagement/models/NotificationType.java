package ut.edu.vaccinemanagement.models;

public enum NotificationType {
    Reminder,Service
}
